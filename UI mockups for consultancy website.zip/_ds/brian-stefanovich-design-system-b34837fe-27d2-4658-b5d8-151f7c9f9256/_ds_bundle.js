/* @ds-bundle: {"format":4,"namespace":"BrianStefanovichDesignSystem_b34837","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"ListItem","sourcePath":"components/core/ListItem.jsx"},{"name":"SectionHeading","sourcePath":"components/core/SectionHeading.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"}],"sourceHashes":{"components/core/Button.jsx":"ee8ae3a6aa6f","components/core/Card.jsx":"de4472618402","components/core/IconButton.jsx":"29a33f31bd47","components/core/ListItem.jsx":"a3489c325634","components/core/SectionHeading.jsx":"c7764fbad58d","components/core/Tag.jsx":"7629c6546d78","components/navigation/Footer.jsx":"66c6c438fcfb","components/navigation/NavBar.jsx":"fcec297fbadc"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.BrianStefanovichDesignSystem_b34837 = window.BrianStefanovichDesignSystem_b34837 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  children = "Explore Discipline",
  tone = "primary",
  size = "md",
  href,
  onClick,
  ...rest
}) {
  const isSm = size === "sm";
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: "var(--radius-md)",
    border: "none",
    cursor: "pointer",
    fontFamily: "var(--font-display)",
    fontWeight: "var(--text-h3-weight)",
    fontSize: isSm ? "16px" : "var(--text-label-size)",
    lineHeight: "var(--text-label-leading)",
    letterSpacing: "var(--text-label-tracking)",
    padding: isSm ? "8px 18px" : "11px 24px 12px 24px",
    textDecoration: "none",
    transition: "background-color var(--motion-duration) var(--motion-easing), transform var(--motion-duration) var(--motion-easing)"
  };
  const tones = {
    primary: {
      backgroundColor: "var(--accent-primary)",
      color: "var(--porcelain-050)"
    },
    secondary: {
      backgroundColor: "var(--accent-secondary)",
      color: "var(--porcelain-050)"
    },
    outline: {
      backgroundColor: "transparent",
      color: "var(--text-primary)",
      boxShadow: "inset 0 0 0 1.5px var(--border-hairline)"
    }
  };
  const style = {
    ...base,
    ...tones[tone]
  };
  const hoverStyle = tone === "outline" ? {
    boxShadow: "inset 0 0 0 1.5px var(--accent-primary)"
  } : {
    filter: "brightness(1.08)"
  };
  const [hover, setHover] = React.useState(false);
  const Tag = href ? "a" : "button";
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    onClick: onClick,
    style: hover ? {
      ...style,
      ...hoverStyle
    } : style,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
const surfaces = {
  graphite: {
    backgroundColor: "var(--surface-card)",
    boxShadow: "var(--shadow-card)",
    textColor: "var(--text-primary)",
    bodyColor: "var(--text-secondary)"
  },
  elevated: {
    backgroundColor: "var(--surface-card-elevated)",
    boxShadow: "var(--shadow-card)",
    textColor: "var(--text-primary)",
    bodyColor: "var(--text-secondary)"
  },
  carbon: {
    backgroundColor: "var(--surface-card-technical)",
    boxShadow: "var(--shadow-card)",
    textColor: "var(--text-primary)",
    bodyColor: "var(--text-secondary)"
  },
  porcelain: {
    backgroundColor: "var(--surface-card-light)",
    boxShadow: "var(--shadow-card-lift)",
    textColor: "var(--text-primary-inverse)",
    bodyColor: "var(--text-secondary)"
  }
};
function Card({
  tone = "graphite",
  size = "md",
  eyebrow,
  title = "Software Architecture & Advisory",
  body,
  children
}) {
  const s = surfaces[tone] || surfaces.graphite;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      backgroundColor: s.backgroundColor,
      boxShadow: s.boxShadow,
      borderRadius: size === "lg" ? "var(--radius-lg)" : "var(--radius-md)",
      padding: size === "lg" ? "var(--space-40)" : "var(--space-32)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-8)",
      boxSizing: "border-box"
    }
  }, eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontWeight: "var(--text-eyebrow-weight)",
      fontSize: "var(--text-eyebrow-size)",
      lineHeight: "var(--text-eyebrow-leading)",
      letterSpacing: "var(--text-eyebrow-tracking)",
      textTransform: "uppercase",
      color: "var(--text-secondary)"
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: "var(--text-h3-weight)",
      fontSize: "var(--text-h3-size)",
      lineHeight: "var(--text-h3-leading)",
      color: s.textColor
    }
  }, title), body && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--font-body)",
      fontWeight: "var(--text-body-weight)",
      fontSize: "var(--text-body-size)",
      lineHeight: "var(--text-body-leading)",
      color: s.bodyColor
    }
  }, body), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function IconButton({
  direction = "right",
  tone = "dark",
  onClick,
  ...rest
}) {
  const iconColor = tone === "dark" ? "var(--porcelain-050)" : "var(--carbon-950)";
  const rotate = direction === "left" ? "rotate(180deg)" : "none";
  return /*#__PURE__*/React.createElement("button", _extends({
    onClick: onClick,
    "aria-label": direction === "left" ? "Previous" : "Next",
    style: {
      width: 48,
      height: 48,
      borderRadius: "var(--radius-pill)",
      boxShadow: "inset 0 0 0 2px var(--accent-primary)",
      backgroundColor: "transparent",
      border: "none",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: "pointer"
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 16 16",
    fill: iconColor,
    style: {
      transform: rotate
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 12.175 9 L 0 9 L 0 7 L 12.175 7 L 6.575 1.4 L 8 0 L 16 8 L 8 16 L 6.575 14.6 L 12.175 9 L 12.175 9",
    fillRule: "nonzero"
  })));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/ListItem.jsx
try { (() => {
function ListItem({
  children = "Rigorous & Intentional",
  tone = "inverse"
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-12)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      backgroundColor: "var(--accent-primary)",
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontWeight: "var(--text-label-weight)",
      fontSize: "var(--text-label-size)",
      lineHeight: "var(--text-label-leading)",
      letterSpacing: "var(--text-label-tracking)",
      color: tone === "inverse" ? "var(--text-primary)" : "var(--text-primary-inverse)"
    }
  }, children));
}
Object.assign(__ds_scope, { ListItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ListItem.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeading.jsx
try { (() => {
function SectionHeading({
  eyebrow,
  title = "Strategic Foundation",
  tone = "inverse"
}) {
  const textColor = tone === "inverse" ? "var(--text-primary)" : "var(--text-primary-inverse)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-8)"
    }
  }, eyebrow && /*#__PURE__*/React.createElement(Tag, {
    tone: "muted"
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: "var(--text-h2-weight)",
      fontSize: "var(--text-h2-size)",
      lineHeight: "var(--text-h2-leading)",
      color: textColor
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 64,
      height: 4,
      backgroundColor: "var(--accent-primary)"
    }
  }));
}
function Tag({
  children,
  tone
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontWeight: "var(--text-eyebrow-weight)",
      fontSize: "var(--text-eyebrow-size)",
      lineHeight: "var(--text-eyebrow-leading)",
      letterSpacing: "var(--text-eyebrow-tracking)",
      textTransform: "uppercase",
      color: "var(--text-secondary)"
    }
  }, children);
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function Tag({
  children = "RIGOROUS",
  tone = "muted",
  tracking = "normal"
}) {
  const colors = {
    muted: "var(--text-secondary)",
    accent: "var(--accent-primary)",
    inverse: "var(--text-primary)"
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      fontFamily: "var(--font-mono)",
      fontWeight: "var(--text-eyebrow-weight)",
      fontSize: "var(--text-eyebrow-size)",
      lineHeight: "var(--text-eyebrow-leading)",
      letterSpacing: tracking === "wide" ? "var(--text-eyebrow-wide-tracking)" : "var(--text-eyebrow-tracking)",
      textTransform: "uppercase",
      color: colors[tone] || colors.muted
    }
  }, children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
function Footer({
  name = "Brian Stefanovich",
  attributes = ["Rigorous", "Pragmatic", "Close"],
  copyright
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "45px 90px",
      backgroundColor: "var(--surface-page)",
      borderTop: "2px solid var(--border-hairline)",
      boxSizing: "border-box",
      gap: "var(--space-32)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: "var(--text-h3-weight)",
      fontSize: "var(--text-h3-size)",
      lineHeight: "var(--text-h3-leading)",
      color: "var(--text-primary)"
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-32)"
    }
  }, attributes.map((a, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      opacity: 0.8,
      fontFamily: "var(--font-mono)",
      fontWeight: "var(--text-eyebrow-weight)",
      fontSize: "var(--text-eyebrow-size)",
      lineHeight: "var(--text-eyebrow-leading)",
      letterSpacing: "var(--text-eyebrow-wide-tracking)",
      textTransform: "uppercase",
      color: "var(--text-secondary)"
    }
  }, a))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontWeight: 500,
      fontSize: "14px",
      lineHeight: "19.6px",
      letterSpacing: "0.7px",
      color: "var(--text-secondary)"
    }
  }, copyright || `© ${name}. All rights reserved.`));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
function NavBar({
  wordmark = "Brian Stefanovich",
  links = [{
    label: "Color & Type",
    active: false
  }, {
    label: "Application",
    active: false
  }]
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "24px 90px",
      backgroundColor: "var(--surface-page)",
      borderTop: "1px solid var(--border-hairline)",
      borderBottom: "2px solid var(--border-hairline)",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: "var(--text-headline-md-weight)",
      fontSize: "var(--text-headline-md-size)",
      lineHeight: "var(--text-headline-md-leading)",
      letterSpacing: "var(--text-headline-md-tracking)",
      color: "var(--text-primary)"
    }
  }, wordmark), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-32)"
    }
  }, links.map((l, i) => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "#",
    style: {
      textDecoration: "none",
      padding: "0 0 4px 0",
      borderBottom: `${l.active ? 2 : 1}px solid var(--accent-primary)`,
      fontFamily: "var(--font-mono)",
      fontWeight: "var(--text-label-weight)",
      fontSize: "var(--text-label-size)",
      lineHeight: "var(--text-label-leading)",
      letterSpacing: "var(--text-label-tracking)",
      textTransform: "uppercase",
      color: "var(--accent-primary)"
    }
  }, l.label))));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.ListItem = __ds_scope.ListItem;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.NavBar = __ds_scope.NavBar;

})();

# Brian Stefanovich — Design System

A personal B2B consulting brand for **Brian Stefanovich** (Software Architecture & Consulting), serving founders, owners and engineering leaders in Chile and international remote clients. Brand idea: *architectural clarity for software decisions*. Brand promise: **Clarity before Complexity.**

Positioning: senior software architecture, consulting, modernization, integration and fractional technical leadership — diagnosis-first, tradeoffs made explicit, every recommendation tied to its business consequence. Four service families: Software Architecture & Advisory · Product & Business Consulting · Modernization & Integration · Fractional Software Architect.

## Sources

- **Brand foundation doc** — the strategic/messaging brief pasted into this project (purpose, mission, positioning, voice, color/type spec).
- **Figma file "Nueva Web.fig"** (mounted read-only VFS), scope limited to: `/Logo` (20 logo-lockup frames) and `/Brand/Html-Body` (a single long brand-guidelines page reconstructing the color system, typography hierarchy, service architecture and footer/nav patterns). No `/Website` product screens and no component library were in scope, so no UI kit was built — the tokens and components below are sourced entirely from the brand-guidelines page and the brand doc.

## Index

- `styles.css` — root stylesheet, imports everything under `tokens/`.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `fonts.css`.
- `assets/logo/` — the real symbol vector exported from Figma, as it's cropped/scaled for each of the 5 named lockups × light/dark (`mark.svg` is the canonical symbol alone). The Figma file composes the wordmark as live Montserrat text next to the symbol in each lockup frame, not as part of the vector — so a full "Principal" lockup is `logo-principal-dark.svg` + the type "Brian Stefanovich" set in Montserrat 700 (see NavBar/Footer for the exact wordmark treatment), not a single flattened asset.
- `assets/icons/` — 3 line icons extracted from the brand page (column, layers/shield, wrench-blocks).
- `components/core/` — Button, IconButton, Card, SectionHeading, Tag, ListItem.
- `components/navigation/` — NavBar, Footer.
- `guidelines/` — foundation specimen cards (colors, type, spacing, brand motifs, logo, icons) — see the Design System tab.
- `thumbnail.html` — homepage tile.

## Components

- **Button** — Blueprint-filled primary CTA (`tone: primary | secondary | outline`).
- **IconButton** — 48px circular Blueprint-ring button with an arrow glyph.
- **Card** — radius-14 surface card, `tone: graphite | elevated | carbon | porcelain`.
- **SectionHeading** — H2 + 64×4px Blueprint underline bar (the section-title pattern used everywhere on the brand page).
- **Tag** — uppercase JetBrains Mono eyebrow/attribute label.
- **ListItem** — 8×8 Blueprint square bullet + mono label.
- **NavBar** — wordmark + underlined mono nav links.
- **Footer** — wordmark, brand-attribute row, copyright.

### Intentional additions
The source defines one button, one icon-button and one card style each in situ (the page never shows Toast/Tabs/Dialog/etc., so none were invented). `Button`'s `secondary`/`outline` tones and `Card`'s `elevated`/`carbon` tones generalize the *one* instance of each seen on the page into a reusable prop, since the page reuses the same visual language across contexts (light and dark cards, one highlighted service card). No net-new components were added.

## Content fundamentals

- **Voice**: first-person singular ("I diagnose," "my recommendation") — this is a personal brand, not an agency "we." Calm, senior, specific. Explains consequences instead of impressing with jargon.
- **Core message**: "Better software begins with better decisions." Brand line: "Clarity before Complexity."
- **Favor**: clarity, decision, architecture, system, constraint, risk, tradeoff, evolution, roadmap, evidence, maintainability, outcome.
- **Avoid**: disruption, cutting-edge, world-class, 360°, digital transformation, scalable solution, synergy, magic, guaranteed, future-proof.
- **Example (from the brand page)**: "We design systems that scale elegantly under pressure, optimizing for maintainability." / "Bridging the gap between engineering execution and market reality." / "Systematic refactoring of legacy systems."
- **Casing**: sentence case for headlines and body; UPPERCASE + wide tracking reserved for JetBrains Mono technical labels only (eyebrows, nav links, footer attributes, phase numbers) — never for body copy.
- **No emoji.** Spanish-market copy should use natural Latin American Spanish, minimal Spanglish; explain "fractional" on first use.

## Visual foundations

- **Colors**: near-monochrome architectural base (Carbon `#101311`, Graphite `#2A2F2C`, Steel `#717A75`, Fog `#D8DED9`, Porcelain `#F4F0E8`) plus two signature accents used asymmetrically — Blueprint `#465CD4` (functional/action, ~8% of a composition) and Copper `#A65330` (human/consequence, ~2%, never given equal weight to Blueprint). Target mix: 60% Carbon or Porcelain, 30% the inverse neutral, 8% Blueprint, 2% Copper.
- **Type**: three fonts, each with one job. **Montserrat 700** for all headings (Headline XL 54/59.4 with −1.08 tracking down to H3 27/35.1) — heavy weights only, never 800–900. **Open Sans 400** for body copy (23px lead, 18px body) — the brand doc named Montserrat for body, but the actual brand page implements body copy in Open Sans; the built page is the source of truth here. **JetBrains Mono 500 uppercase**, +0.7–1.4px tracking, for every technical label, nav link, eyebrow and footer attribute — never for paragraphs. *(The brand doc calls for a font named "Spectre" for this role and asks for its license/glyphs to be verified before production; the Figma file already resolved that open question by shipping JetBrains Mono. Flagging in case "Spectre" still needs to ship separately — see Caveats.)*
- **Layout**: sections are framed in a hairline border — 1px Fog on top/right/left, 2px Fog on the bottom — a repeating "technical schematic" motif seen on every section of the brand page (hero, color system, typography, services) and on the top nav / footer. 12-column grid, 32px gutters. Page margins 90px; section vertical padding 45px. 8px base spacing unit (4/8/12/16/20/24/32/48/64/90/128 in use).
- **Cards**: radius 14px (18px for the one large hero/offer card), no drop shadow — just an inset 1px Fog hairline (2px Fog for the elevated/light card), background is Graphite, a lighter Graphite (`#2E3733`), Carbon, or Porcelain depending on emphasis.
- **Buttons**: radius 14px, Blueprint fill, Porcelain text, Montserrat 700, no hover color swap seen in source — a subtle brightness lift is used here as a reasonable default hover state. Circular icon-only buttons use a 2px Blueprint ring instead of a fill.
- **Borders/dividers**: 1px Fog hairlines throughout; a thin 1px Fog rule under an H2 subtitle line; horizontal dividers inside cards are 1px Fog at full width.
- **Motion**: not demonstrated in the source; the brand doc specifies calm, purposeful 200–450ms transitions with no continuous spin — tokens default to 300ms ease.
- **Corner radii**: 8 (small), 14 (default card/button), 18 (hero card), 9999 (pill/circular).
- **Photography/illustration**: none present in the in-scope frames. The brand doc calls for documentary, warm-lit photography and explicitly rules out floating code, neon circuitry, and synthetic "AI" imagery — no images are included here since none exist in-scope; do not invent any.
- **Logo**: no combined "logo" bitmap exists — the mark is a vector line-drawn concentric/interface glyph (`assets/logo/mark.svg`), always monochrome, paired with the Montserrat wordmark "Brian Stefanovich" and (space permitting) the descriptor. 5 lockups × light/dark: Principal (horizontal, symbol+name+descriptor), Simplificado (symbol+name, no descriptor), Mini (symbol only, square), Vertical (stacked), Independiente (symbol only, no frame).

## Iconography

Three line icons were found on the brand page (a column/pillar glyph, a layered shield glyph, a wrench/tool glyph), all single-path outline icons using `fill="currentColor"` so they inherit Blueprint/Copper/Porcelain per context — copied to `assets/icons/`. No icon font, no emoji, and no unicode-glyph icons were found in scope. The brand doc's broader iconography rule (simple geometric line icons, consistent stroke, circular terminals, restrained corner radii, no filled/cartoon/3D icons) should govern any new icons added later.

## Caveats & next steps

- **Scope**: only `/Logo` and `/Brand/Html-Body` were in scope for this import — no `/Website` screens or component library were selected, so there is no UI kit here (only tokens + a small set of primitives derived from the one long brand-guidelines page). If you'd like a homepage/marketing-site UI kit built from the `/Website` frames, say so and I'll pull that scope in.
- **"Spectre" font**: the original brand doc calls for a font named Spectre for the technical/mono role and asks that its license and Spanish glyph coverage be verified before production. The actual Figma file ships **JetBrains Mono** in that role instead — I followed the file (source of truth) but flagging in case Spectre still needs to ship as a separate decision.
- **Body font conflict**: the brand doc specifies Montserrat for body copy; the built brand page uses **Open Sans** for body. Followed the file.
- **Logo vector**: the brand doc flags "faint residual text" and unresolved production questions on the logo master; I could not detect residual text in the exported vector, but haven't validated it against a final print-ready master — treat `assets/logo/*.svg` as good for screen/prototype use, not final production art, until you confirm.
- **No photography** exists in the in-scope frames — none was fabricated. If you have real photography, drop it in `assets/` and I'll wire it into the guidelines.

**Ask**: tell me if the `/Website` frames should be pulled in for a marketing-site UI kit, and confirm whether JetBrains Mono (vs. "Spectre") and Open Sans (vs. Montserrat) for body are the final calls — then I'll iterate.
